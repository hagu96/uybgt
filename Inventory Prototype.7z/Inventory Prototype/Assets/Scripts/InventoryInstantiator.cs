﻿/* --- CHANGELOG ---
 * Original script by: Hannes Gustafsson, 24/01
 * 
 * Edited by: Hannes Gustafsson
 * Edit date: 26/1
 * Description: Refactored the code
 * */

using UnityEngine;
using System.Collections;
using UnityEngine.Assertions;
using UnityEngine.UI;


public class InventoryInstantiator : MonoBehaviour {

    public GameObject buttonPrefab;
    private GameObject buttonObject;

    //Temporary variable to show the change from the Alpha image --> Normal image.
    public float instantiateWaitTime;

    void Start()
    {
        Assert.IsNotNull(buttonPrefab);
        StartCoroutine(InstantiatePrefab());
    }

    //Instantiating the object, as well as setting it's parent and position
    IEnumerator InstantiatePrefab()
    {
        yield return new WaitForSeconds(instantiateWaitTime);
        buttonObject = Instantiate(buttonPrefab, transform.position, Quaternion.identity) as GameObject;
        Assert.IsNotNull(buttonObject);
        buttonObject.transform.SetParent(gameObject.transform, false);
        buttonObject.transform.position = transform.position;
    }

}
